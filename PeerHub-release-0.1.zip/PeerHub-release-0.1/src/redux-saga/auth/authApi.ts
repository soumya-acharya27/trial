// import axios from "axios"

// export const getDemoApi = () => {
//     return axios.get('https://jsonplaceholder.typicode.com/todos')
// }